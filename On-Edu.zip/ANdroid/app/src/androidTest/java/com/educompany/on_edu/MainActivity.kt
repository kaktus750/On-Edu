package com.educompany.on_edu

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import coil.compose.rememberAsyncImagePainter
import com.educompany.on_edu.ui.theme.OnEduTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            OnEduTheme {
                val navController = rememberNavController()
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    NavigationApp(navController)
                }
            }
        }
    }
}

@Composable
fun NavigationApp(navController: NavHostController) {
    NavHost(navController, startDestination = "welcome") {
        composable("welcome") { WelcomeScreen(navController) }
        composable("registration") { RegistrationScreen(navController) }
        composable("login") { LoginScreen(navController) }
        composable("success_screen") { SuccessScreen(navController) }
        composable("success_log") { Success_Log(navController) }
        composable("menu") { Menu(navController) }
    }
    }




@Composable
fun WelcomeScreen(navController: NavHostController) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF87CEFA))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = rememberAsyncImagePainter(
                    model = "https://upload.wikimedia.org/wikipedia/commons/e/e8/Education%2C_Studying%2C_University%2C_Alumni_-_icon.png"
                ),
                contentDescription = null,
                modifier = Modifier
                    .size(200.dp)
                    .padding(bottom = 24.dp)
            )

            Text(
                text = "Добро пожаловать в ",

                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                text = "On-Edu! ",

                fontSize =
                30.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Text(
                text = "Скучные уроки – это не про нас! В этом приложении учеба превращается в увлекательное путешествие, где каждый шаг – это шаг к успеху!",
                fontSize = 16.sp,
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            Button(
                onClick = { navController.navigate("registration") },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .padding(horizontal = 32.dp)
            ) {
                Text(
                    text = "Начать",
                    fontSize = 18.sp,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun RegistrationScreen(navController: NavHostController) {
    val fullName = remember { mutableStateOf("") }
    val email = remember { mutableStateOf("") }
    val password = remember { mutableStateOf("") }
    val confirmPassword = remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            IconButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier.align(Alignment.Start)
            ) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.Black)
            }

            Text(text = "Регистрация", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            Text(
                text = "Открой двери к знаниям!",
                fontSize = 16.sp,
                color = Color.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            TextField(
                value = fullName.value,
                onValueChange = { fullName.value = it },
                label = { Text("Введите ФИО") },
                modifier = Modifier.fillMaxWidth()

            )
            Spacer(modifier = Modifier.height(8.dp))

            TextField(
                value = email.value,
                onValueChange = { email.value = it },
                label = { Text("Введите Email") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))

            TextField(
                value = password.value,
                onValueChange = { password.value = it },
                label = { Text("Введите пароль") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))

            TextField(
                value = confirmPassword.value,
                onValueChange = { confirmPassword.value = it },
                label = { Text("Повторите пароль")  },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { navController.navigate("success_screen") }, // Navigate to login after registration
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Зарегистрироваться", color = Color.White)
            }

            Spacer(modifier = Modifier.height(16.dp))

            TextButton(onClick = { navController.navigate("login") }) {
                Text("Уже есть аккаунт? Войти", color = Color.Black)
            }
        }
    }
}

@Composable
fun LoginScreen(navController: NavHostController) {
    val email = remember { mutableStateOf("") }
    val password = remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Добро пожаловать!",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Image(
                painter = rememberAsyncImagePainter("https://connectycube.com/wp-content/uploads/2023/09/undraw_My_notifications_re_ehmk-1.png"),
                contentDescription = null,
                modifier = Modifier
                    .size(200.dp)
                    .padding(bottom = 24.dp)
            )

            TextField(
                value = email.value,
                onValueChange = { email.value = it },
                label = { Text("Введите email") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)

            )

            TextField(
                value = password.value,
                onValueChange = { password.value = it },
                label = { Text("Введите пароль") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .shadow((8.dp))
                    .background(color = Color.White)


            )

            TextButton(onClick = { /* Action for Forgot Password */ }) {
                Text("Забыли пароль?", color = Color(0xFF1E88E5))
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {  navController.navigate("success_log") },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Text("Войти", color = Color.White)
            }

            Spacer(modifier = Modifier.height(16.dp))

            TextButton(onClick = { navController.navigate("registration") }) {
                Text("Нет аккаунта? Зарегистрироваться", color = Color.Black)
            }
        }
    }
}

@Composable
fun SuccessScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .background(Color.White),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Регистрация успешно прошла!", fontSize = 24.sp, color = Color.Black, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(16.dp))
        // Здесь можно добавить изображение или иконку успешной регистрации
        Button(
            onClick = { navController.navigate("menu") },
            modifier = Modifier.fillMaxWidth(),




        ) {
            Text("Продолжить")
        }
    }
}


@Composable
fun Success_Log(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Вы успешно вошли!", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))
        Icon(
            imageVector = Icons.Filled.CheckCircle,
            contentDescription = "Success Icon",
            modifier = Modifier.size(48.dp),
            tint = Color.Green // Цвет иконки
        )
        Button(
            onClick = { navController.navigate("menu") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Продолжить")
        }
    }
}


@Composable
fun Menu(navController: NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(30.dp)
            .offset(y = 50.dp)
    ) {
        // Приветственная часть с аватаром
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF87CEEB), RoundedCornerShape(30.dp))
                .padding(30.dp)



        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Иконка аватара
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .background(Color.Gray, CircleShape)
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text("Добро пожаловать, Санжар!", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)

                Spacer(modifier = Modifier.height(16.dp))

                // Иконки для тестов, видеоуроков и заданий
                Row(
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = { /* TODO: Действие для тестов */ }) {
                            Box(modifier = Modifier
                                .size(40.dp)
                                .background(Color.LightGray, RoundedCornerShape(8.dp)))
                        }
                        Text("Тест", color = Color.White)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = { /* TODO: Действие для видео уроков */ }) {
                            Box(modifier = Modifier
                                .size(40.dp)
                                .background(Color.LightGray, RoundedCornerShape(8.dp)))
                        }
                        Text("Видео уроки", color = Color.White)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = { /* TODO: Действие для заданий */ }) {
                            Box(modifier = Modifier
                                .size(40.dp)
                                .background(Color.LightGray, RoundedCornerShape(8.dp)))
                        }
                        Text("Задания", color = Color.White)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Список предметов с цветными индикаторами
        Column(modifier = Modifier.padding(horizontal = 8.dp)) {
            Row {
                SubjectIndicator(color = Color.Green, subject = "Математика")
                SubjectIndicator(color = Color.Yellow, subject = "Информатика")
            }
            Row {
                SubjectIndicator(color = Color.Green, subject = "Физика")
                SubjectIndicator(color = Color.Red, subject = "География")
            }
            Row {
                SubjectIndicator(color = Color.Green, subject = "Химия")
                SubjectIndicator(color = Color.Red, subject = "История")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))


        // Раздел "Сервис"
        Text(
            text = "Сервис",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp)

        )

        Spacer(modifier = Modifier.height(8.dp))

        Column {
            ServiceButton("Обратная связь")
            ServiceButton("Психолог")
            ServiceButton("Портфолио достижений")
            ServiceButton("Онлайн конкурсы/Соревнования")
        }
    }

}

@Composable
fun SubjectIndicator(color: Color, subject: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .background(color, CircleShape)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(subject)
    }
}

@Composable
fun ServiceButton(text: String) {
    Button(
        onClick = { /* TODO: Add the service button action */ },
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color.White), // Fix for background color
        shape = RoundedCornerShape(16.dp),
        elevation = ButtonDefaults.elevatedButtonElevation(defaultElevation = 4.dp) // Correct elevation
    ) {
        Text(text = text, color = Color.Black, textAlign = TextAlign.Center)
    }
}






























