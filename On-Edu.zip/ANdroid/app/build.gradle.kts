

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.educompany.on_edu"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.educompany.on_edu"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.1"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.benchmark.macro)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.ui.test.junit4)
    debugImplementation(libs.androidx.ui.tooling)
    debugImplementation(libs.androidx.ui.test.manifest)

        // Основные зависимости для Compose
        implementation("androidx.compose.ui:ui:1.5.1")
        implementation("androidx.compose.material3:material3:1.1.0")
        implementation("androidx.compose.ui:ui-tooling-preview:1.5.1")
        implementation("androidx.activity:activity-compose:1.7.2")

        // Для загрузки изображений из интернета с помощью Coil
        implementation("io.coil-kt:coil-compose:2.2.2")

        // Опционально: для отображения предпросмотра в Android Studio
        debugImplementation("androidx.compose.ui:ui-tooling:1.5.1")

        implementation("androidx.navigation:navigation-compose:2.5.3") // Убедитесь, что версия актуальна

        implementation("androidx.compose.ui:ui:1.5.1")
        implementation("androidx.compose.material:material:1.5.1")
        implementation("androidx.compose.ui:ui-tooling-preview:1.5.1")
        implementation("androidx.compose.foundation:foundation:1.5.1")

        // Если используете навигацию в Compose
        implementation("androidx.navigation:navigation-compose:2.7.2")

        // Для предварительного просмотра кода в Android Studio
        debugImplementation("androidx.compose.ui:ui-tooling:1.5.1")

        // Основные зависимости для Jetpack Compose
        implementation ("androidx.compose.ui:ui:1.5.0")// Замените на актуальную версию Compose
        implementation ("androidx.compose.material3:material3:1.0.0")
        implementation ("androidx.compose.ui:ui-tooling-preview:1.5.0")
        debugImplementation ("androidx.compose.ui:ui-tooling:1.5.0")

        // Зависимость для навигации в Jetpack Compose
        implementation ("androidx.navigation:navigation-compose:2.5.3")

    }


